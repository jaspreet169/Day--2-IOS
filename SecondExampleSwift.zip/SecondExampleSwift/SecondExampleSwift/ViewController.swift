//
//  ViewController.swift
//  SecondExampleSwift
//
//  Created by moxDroid on 2017-03-19.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myButton: UIButton!
    @IBOutlet weak var mySwitch: UISwitch!
    @IBOutlet weak var myTextField: UITextField!
    
    @IBAction func mySwitchTapped(_ sender: UISwitch)
    {
        if mySwitch.isOn
        {
            myTextField.text = "The Switch is On"
        }
        else
        {
            myTextField.text = "The Switch is Off"
        }
    }
    
    @IBAction func buttonClicked(_ sender: UIButton)
    {
        if mySwitch.isOn
        {
            myTextField.text = "The Switch is Off"
            mySwitch.setOn(false, animated:true)
        }
        else
        {
            myTextField.text = "The Switch is On"
            mySwitch.setOn(true, animated:true)
        }
    }
    
}

